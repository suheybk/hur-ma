# Kur'an Öğreniyorum - كتاب الله

**Fatma Serap Karamollaoğlu Metodu ile Arapça Öğrenme Oyunu**

Love2D ile geliştirilmiş, Türkçe konuşanlar için Kur'an Arapçası öğrenme oyunu.

## 🎮 Oyun Modları

### 1. 🌉 Kelime Köprüsü
Türkçede kullandığımız Arapça kökenli kelimeleri Kur'an'daki asıllarıyla eşleştirme oyunu.
- Kur'an'daki kelimelerin %80'i Türkçede kullanılıyor
- Her kelime için Türkçe türevler gösterilir
- Combo sistemi ile puan kazanın
- Doğru cevaplarda Kur'an'dan örnek ayet gösterilir

### 2. 📖 Ayet Yapbozu
Kırık Meal sistemi ile ayetleri kelime kelime öğrenme.
- Her kelimeye tıklayarak anlamını görün
- Türkçedeki karşılıklarını keşfedin
- Quiz modu ile kendinizi test edin
- Sureler arası gezinin

### 3. 🛤️ 20 Tekrar Serüveni
Kur'an Seferberliği metoduna dayalı tekrar sistemi.
- Günlük 1 sayfa 20 kere okuma
- Mekke-Medine hicret yolculuğu teması
- Her 20 tekrarda yeni istasyona ulaşın
- Streak sistemi ile motivasyonunuzu koruyun

### 4. 🌳 Kök Avcısı
Arapça kelimelerin 3 harfli köklerini ve türevlerini keşfetme.
- Kök ağacı görselleştirmesi
- Türkçedeki karşılıkları bulun
- Her bulunan kelime için dal büyür
- İpucu sistemi

### 5. ✨ Surelerin Sırları
Surelerdeki belagat inceliklerini ve hikmetleri keşfetme.
- Her sure bir dünya
- Gizli hazineleri (belagat noktaları) bulun
- Dijital icazet belgesi sistemi
- Mistik atmosfer

## 🚀 Kurulum

### Gereksinimler
- [Love2D](https://love2d.org/) (11.4 veya üzeri)

### Çalıştırma

#### Windows
```bash
love kuran-ogreniyorum
```

#### macOS
```bash
/Applications/love.app/Contents/MacOS/love kuran-ogreniyorum
```

#### Linux
```bash
love kuran-ogreniyorum
```

### Alternatif: .love Dosyası Oluşturma
```bash
cd kuran-ogreniyorum
zip -9 -r ../kuran-ogreniyorum.love .
```
Sonra .love dosyasını Love2D ile açabilirsiniz.

## 🎯 Özellikler

- **Türkçe-Arapça Köprüsü**: Türkçedeki Arapça kökenli kelimeler üzerinden öğrenme
- **Kırık Meal Sistemi**: Her kelimenin altında Türkçe karşılığı
- **Spaced Repetition**: Tekrar bazlı öğrenme
- **Gamification**: Puan, seviye, rozet ve streak sistemleri
- **İslami Estetik**: Geleneksel renkler ve motifler
- **Kayıt Sistemi**: İlerlemeniz otomatik kaydedilir

## ⌨️ Kontroller

- **Fare**: Butonlara tıklama, kart seçimi
- **ESC**: Ana menüye dön / Çıkış
- **F11**: Tam ekran geçişi
- **F3**: Debug modu (FPS gösterimi)
- **Enter/Space**: Onaylama / Sonraki
- **Ok Tuşları**: Navigasyon (bazı oyunlarda)

## 📁 Proje Yapısı

```
kuran-ogreniyorum/
├── main.lua           # Ana oyun dosyası
├── conf.lua           # Love2D konfigürasyonu
├── data/
│   ├── words.lua      # Kelime veritabanı
│   └── surahs.lua     # Sure ve ayet veritabanı
└── states/
    ├── menu.lua           # Ana menü
    ├── kelime_koprusu.lua # Kelime Köprüsü oyunu
    ├── ayet_yapbozu.lua   # Ayet Yapbozu oyunu
    ├── tekrar_seruveni.lua# 20 Tekrar Serüveni
    ├── kok_avcisi.lua     # Kök Avcısı oyunu
    ├── surelerin_sirlari.lua # Surelerin Sırları
    ├── settings.lua       # Ayarlar ekranı
    └── profile.lua        # Profil ekranı
```

## 📚 Metot Hakkında

Bu oyun, **Fatma Serap Karamollaoğlu**'nun geliştirdiği Kur'an merkezli Arapça öğretim metoduna dayanmaktadır:

1. **Türkçe-Arapça Köprüsü**: Kur'an'daki kelimelerin büyük çoğunluğu Türkçede zaten kullanılmaktadır.
2. **Kırık Meal**: Her ayetin kelime kelime çözümlenmesi
3. **Tekrar Sistemi**: Günlük düzenli tekrar ile kalıcı öğrenme
4. **Anlayarak Okuma**: Sadece telaffuz değil, anlam odaklı yaklaşım

## 🤝 Katkıda Bulunma

- Yeni sureler ve ayetler eklenebilir
- Kelime veritabanı genişletilebilir
- Ses efektleri ve müzik eklenebilir
- Arapça font desteği geliştirilebilir

## 📜 Lisans

Bu proje eğitim amaçlı geliştirilmiştir.

## 🙏 Teşekkür

- Fatma Serap Karamollaoğlu - Metot geliştirici
- Kur'an Seferberliği topluluğu
- Love2D geliştirici topluluğu

---

**Bismillahirrahmanirrahim**

*"Oku! Yaratan Rabbinin adıyla oku!"* - Alak Suresi, 1. Ayet
